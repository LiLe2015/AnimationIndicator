//
//  LLAnimationIndicator.m
//  LLAnimationIndicator
//
//  Created by LiLe on 16/1/6.
//  Copyright © 2016年 LiLe. All rights reserved.
//
#define WIDTH [UIScreen mainScreen].bounds.size.width
#define HEIGHT [UIScreen mainScreen].bounds.size.height //获取屏幕大小
#define INFO_TEXT_COLOR [UIColor orangeColor]
#define INFO_FONT [UIFont fontWithName:@"ChalkboardSE-Bold" size:14.0f]

#import "LLAnimationIndicator.h"

@interface LLAnimationIndicator ()
{
    UIImageView *imageView;
    UILabel *infoLabel;
}

@property (nonatomic, copy) NSString *loadText;
@property (nonatomic, strong) NSArray *imageArray;
@property (nonatomic, readonly) BOOL isAnimating;

@end

@implementation LLAnimationIndicator

#pragma mark - 初始化方法

- (instancetype)initWithImageArray:(NSArray *)imageArray loadText:(NSString *)text
{
    self = [super initWithFrame:[UIScreen mainScreen].bounds];
    if (self) {
        _imageArray = imageArray;
        _loadText = text;
      
        //self.backgroundColor = [UIColor colorWithRed:80/255.0 green:80/255.0 blue:80/255.0 alpha:0.1];
        self.backgroundColor = [UIColor clearColor];
        _isAnimating = NO;
        imageView = [[UIImageView alloc] initWithFrame:CGRectMake(WIDTH/2-40, HEIGHT/2-40, 80, 80)];
        [self addSubview:imageView];
        // 设置动画帧
        imageView.animationImages = _imageArray;
        infoLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(imageView.frame), self.frame.size.width, 20)];
        infoLabel.backgroundColor = [UIColor clearColor];
        infoLabel.textAlignment = NSTextAlignmentCenter;
        infoLabel.textColor = INFO_TEXT_COLOR;
        infoLabel.font = INFO_FONT;
        
        [self addSubview:infoLabel];
        self.layer.hidden = YES;
        
        [self startAnimation];
    }
    return self;
}

+ (instancetype)llAnimationIndicatorWithImageArray:(NSArray *)imageArray loadText:(NSString *)text
{
    LLAnimationIndicator *animationIndicator = [[LLAnimationIndicator alloc] initWithImageArray:imageArray loadText:text];
    return animationIndicator;
}

#pragma mark - 开始和停止

- (void)startAnimation
{
    _isAnimating = YES;
    self.layer.hidden = NO;
    infoLabel.text = _loadText;
    // 设置动画总时间
    imageView.animationDuration=1.0;
    // 设置重复次数,0表示不重复
    imageView.animationRepeatCount=0;
    // 开始动画
    [imageView startAnimating];
    
}

- (void)stopAnimationWithLoadText:(NSString *)text withType:(BOOL)type;
{
    _isAnimating = NO;
    infoLabel.text = text;
    if(type){
        
        [UIView animateWithDuration:0.3f animations:^{
            self.alpha = 0;
        } completion:^(BOOL finished) {
            [imageView stopAnimating];
            self.layer.hidden = YES;
            self.alpha = 1;
        }];
    }else{
        [imageView stopAnimating];
        [imageView setImage:[UIImage imageNamed:@"3"]];
    }
    
}

//- (void)layoutSubviews {
//    self.frame = [UIScreen mainScreen].bounds;
//}

@end
