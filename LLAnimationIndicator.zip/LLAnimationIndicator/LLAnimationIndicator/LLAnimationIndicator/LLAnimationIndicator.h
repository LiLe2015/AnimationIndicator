//
//  LLAnimationIndicator.h
//  LLAnimationIndicator
//
//  Created by LiLe on 16/1/6.
//  Copyright © 2016年 LiLe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LLAnimationIndicator : UIView

/**
 *  对象方法初始化
 *
 *  @param imageArray 要显示的一组图片
 *  @param text       显示的文字
 *
 *  @return 类本身
 */
- (instancetype)initWithImageArray:(NSArray *)imageArray loadText:(NSString *)text;

/**
 *  类方法初始化
 *
 *  @param imageArray 要显示的一组图片
 *  @param text       显示的文字
 *
 *  @return 类本身
 */
+ (instancetype)llAnimationIndicatorWithImageArray:(NSArray *)imageArray loadText:(NSString *)text;

/**
 *  开始加载
 */
- (void)startAnimation;

/**
 *  停止加载
 *
 *  @param text 加载停止时显示的内容
 *  @param type YES:加载成功，NO:加载失败
 */
- (void)stopAnimationWithLoadText:(NSString *)text withType:(BOOL)type;

@end
