//
//  AppDelegate.h
//  LLAnimationIndicator
//
//  Created by LiLe on 16/2/29.
//  Copyright © 2016年 LiLe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

