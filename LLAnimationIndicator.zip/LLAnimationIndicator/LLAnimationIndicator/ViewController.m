//
//  ViewController.m
//  LLAnimationIndicator
//
//  Created by LiLe on 16/2/29.
//  Copyright © 2016年 LiLe. All rights reserved.
//

#import "ViewController.h"
#import "LLAnimationIndicator.h"

@interface ViewController ()
{
    LLAnimationIndicator *indicator;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //设置动画帧
    NSMutableArray *imgArr = [NSMutableArray array];
    for (int i = 1; i<25; i++) {
        UIImage *img = [UIImage imageNamed:[NSString stringWithFormat:@"load%d.png", i]];
        [imgArr addObject:img];
    }

    indicator = [LLAnimationIndicator llAnimationIndicatorWithImageArray:imgArr loadText:@"正在加载ing..."];
    [self.view addSubview:indicator];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(100, 100, 100, 100);
    btn.backgroundColor = [UIColor redColor];
    [btn setTitle:@"点我" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

- (void)btnAction {
    [indicator stopAnimationWithLoadText:@"提示文字" withType:YES];
}

@end
